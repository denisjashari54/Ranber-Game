﻿namespace RanberGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MainMenu gameManager = new MainMenu();
            gameManager.Run();
        }
    }
}